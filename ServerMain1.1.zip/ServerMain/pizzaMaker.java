import javax.swing.JFrame;
import javax.swing.JComponent;
import java.awt.Graphics; 
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.awt.MouseInfo;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.awt.Color;
/**
 * Write a description of class pizzaMaker here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class pizzaMaker extends JComponent 
{
    static BufferedImage pizzaImage;
    static BufferedImage table;
    static BufferedImage button;
    static int x1;
    static int y1;
    static int count=0;
    static ArrayList<Topping> tops;
    static ArrayList<Topping> allToppings;
    static int startx=500;
    static int starty=0;      
    static int clickCount=0;
    public pizzaMaker()
    {
        tops=new ArrayList<Topping>();
        allToppings = new ArrayList<Topping>();
        if(clickCount==0)
        {
            allToppings.add(new Tomatoes("Tomato"));
            allToppings.add(new Olives("Olive"));
            allToppings.add(new Pepperoni("Pepperoni"));
            allToppings.add(new Onion("Onion"));
            allToppings.add(new Sausage("Sausage"));
            allToppings.add(new Jalapeno("Jalapeno"));
            allToppings.add(new Pineapple("Pineapple"));
            allToppings.add(new Bacon("Bacon"));
            allToppings.add(new Chicken("Chicken"));
            allToppings.add(new greenPepper("GreenPepper"));
            allToppings.add(new Drink("Coke"));
            allToppings.add(new Chips("Lays"));
            allToppings.add(new Cookie("Chips Ahoy"));
            for (Topping t: allToppings)
            {
                t.setC(startx, starty);
                starty += 100;
                if (starty >= 400)
                {
                    starty = 0;               
                    startx += 100;
                }
            }
            allToppings.get(allToppings.size()-3).setC(800, 0);
            allToppings.get(allToppings.size()-2).setC(800, 200);
            allToppings.get(allToppings.size()-1).setC(800, 300);
            clickCount++;
        }
        addMouseListener(new MouseAdapter()
        {
            public void mousePressed(MouseEvent e)
            {
                x1=e.getX();
                y1=e.getY();                               
                if(count==0)
                {
                    for (Topping t: allToppings)
                    {
                        if ((x1>t.getX()&&x1<t.getX()+100)&&(y1>t.getY()&&y1<t.getY()+100))
                        {
                            if (t instanceof Onion)
                                tops.add(new Onion("Onion"));
                            if (t instanceof Sausage)
                                tops.add(new Sausage("Sausage"));
                            if (t instanceof Tomatoes)
                                tops.add(new Tomatoes("Tomatoes"));
                            if (t instanceof Jalapeno)
                                tops.add(new Jalapeno("Jalapeno"));
                            if (t instanceof Pineapple)
                                tops.add(new Pineapple("Pineapple"));
                            if (t instanceof Bacon)
                                tops.add(new Bacon("Bacon"));
                            if (t instanceof Olives)
                                tops.add(new Olives("Olives"));
                            if (t instanceof Chicken)
                                tops.add(new Chicken("Chicken"));
                            if (t instanceof Pepperoni)
                                tops.add(new Pepperoni("Pepperoni"));
                            if (t instanceof greenPepper)
                                tops.add(new greenPepper("greenPepper"));
                            if (t instanceof Drink)
                                tops.add(new Drink("Coke"));
                            if (t instanceof Chips)
                                tops.add(new Chips("Lays"));
                            if (t instanceof Cookie)
                                tops.add(new Cookie("Chips Ahoy"));
                        }
                    }
                    count ++;
                }
                else if(count ==1)
                {
                    tops.get(tops.size()-1).setC(x1-20, y1-20);
                    count = 0;
                }
            }
        });
    }

    public static void main(String[] args) throws ClassNotFoundException
    {
        Server server = new Server(5001, 1);
        
        Audio.playAudio();
        try
        {
            pizzaImage=ImageIO.read(new File("Cheese.png"));
        }
        catch(Exception E)
        {
            System.out.println("error loading image");
        }
        try
        {
            table=ImageIO.read(new File("Table.jpg"));
        }
        catch(Exception E)
        {
            System.out.println("error loading image");
        }
        try
        {
            button=ImageIO.read(new File("redButton.png"));
        }
        catch(Exception E)
        {
            System.out.println("error loading image");
        }
        JFrame frame=new JFrame();
        pizzaMaker comp=new pizzaMaker();
        frame.add(comp);
        frame.setSize(1000, 800);
        frame.setVisible(true);
        boolean bool = true;
        while(bool)
        {
            frame.repaint();
            if(x1 > 900 && y1 > 700)
            {
                bool = false;
            }
        }
        Server serve = new Server (5002, 0);
    }

    public void paintComponent(Graphics g)
    {
        g.drawImage(table, 0, 0, null);
        g.drawImage(pizzaImage, 0, -30, null);
        g.drawImage(button,900,700,null);
        g.setColor(Color.black);
        g.fillRect(90, 0, 5, 95);
        g.fillRect(0, 90, 95, 5);
        g.setColor(new Color(109, 165, 255));
        g.fillRect(0, 0, 90, 90);
        for(Topping t:tops)
        {
            t.placeTopping(g, t.getX(), t.getY());
        }
        for(Topping t: allToppings)
        {
            t.placeTopping(g, t.getX(), t.getY());
        }
    }
    public static ArrayList<Topping> getTops()
    {
        return tops;
    }
}